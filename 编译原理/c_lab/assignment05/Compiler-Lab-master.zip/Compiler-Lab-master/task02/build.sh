make clean
make
echo "./html2txt sina.htm > sina.txt"
./html2txt sina.htm > sina.txt

