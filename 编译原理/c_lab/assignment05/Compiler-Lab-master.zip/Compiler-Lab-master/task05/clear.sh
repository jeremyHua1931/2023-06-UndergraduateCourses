make clean
make clpdf
rm ./test/*.aux ./test/*.log ./test/*.out ./test/*.pdf ./test/expr.tex 

